package com.cg.training.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentDemo
 */
@WebServlet(
		urlPatterns = { "/StudentDemo" }, 
		initParams = { 
				@WebInitParam(name = "i_id", value = "105"), 
				@WebInitParam(name = "i_name", value = "rafi"), 
				@WebInitParam(name = "i_age", value = "22")
		})
public class StudentDemo extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	private int rollno;
	private String name;
	private int age;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	PrintWriter out=response.getWriter();
	out.print(rollno+"\n");
	out.print(name+"\n");
	out.print(age+"\n");
	
	
	}
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
		String roll=config.getInitParameter("i_id");
		String strName=config.getInitParameter("i_name");
		String strAge=config.getInitParameter("i_age");
		
		this.rollno=Integer.parseInt(roll);
		this.name=strName;
		this.age=Integer.parseInt(strAge);
	}
}
