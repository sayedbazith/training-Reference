package com.cg.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.training.entity.Customer;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/reg")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		Customer customer=new Customer();
		
		int id=0;
		String strId=request.getParameter("textId");
		String name=request.getParameter("textName");
		if(strId!=null)
			id=Integer.parseInt(strId);
		out.println(id);
		customer.setId(id);
		customer.setName(name);
		String gender=request.getParameter("radioGender");
		if(gender!=null){
		int genderValue=Integer.parseInt(gender);
		customer.setGender(genderValue);}
		else
			out.println("select one button");
		String pre=request.getParameter("checkPre");
		boolean previl;
		if(pre!=null)
			previl=true;
		else
			previl=false;
		customer.setPrivilage(previl);
		String number=request.getParameter("numberPhone");
		if(number!=null)
		{
			customer.setPhone(number);
		}
		else
			out.println("enter once again");
		String mail=request.getParameter("textMail");
		if(mail!=null)
		{
			customer.setEmail(mail);
		}
		String date=request.getParameter("textDate");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		 
		Date date1=null;
		try {
			date1 = formatter.parse(date);
			if(date!=null)
			{
				customer.setDateOfJoining(date1);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String balance=request.getParameter("numberBalance");
		if(balance!=null)
		{
			double balanceAmount=Double.parseDouble(balance);
			customer.setBalanceAmount(balanceAmount);
		}
		String numberRating=request.getParameter("selectRating");
		if(numberRating!=null)
		{
			int rating =Integer.parseInt(numberRating);
			customer.setCustomerRating(rating);
		}
		out.println(customer.getAddresss());
		out.println(customer.getBalanceAmount());
		out.println(customer.getCustomerRating());
		out.println(customer.getDescription());
		out.println(customer.getEmail());
		out.println(customer.getGender());
		out.println(customer.getId());
		out.println(customer.getName());
		out.println(customer.getPhone());
		out.println(customer.getDateOfJoining());
		
	}

}
