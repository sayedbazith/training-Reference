package com.cg.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.trianing.entity.Doctor;

/**
 * Servlet implementation class DoctorCreatingServlet
 */
@WebServlet("/DoctorCreatingServlet")
public class DoctorCreatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		/*Doctor doctor=new Doctor();
		doctor.setId(150);
		doctor.setName("rafi");
		doctor.setQualification("B.tech");
		doctor.setGender("male");
		doctor.setFees(1000);
		doctor.setExperience(25);*/
		
		Doctor doctor1=new Doctor(110,"rafi","B.Tech",12,1000,"male");
		Doctor doctor2=new Doctor(120,"Bazith","M.Tech",11,1200,"male");
		Doctor doctor3=new Doctor(130,"sayed","Ph.d",14,1300,"male");
		Doctor doctor4=new Doctor(140,"mounika","MBBS",13,1500,"female");	
		Doctor doctor5=new Doctor(150,"divya","FRCS",15,2000,"female");
		List<Doctor> doctor=new ArrayList<Doctor>();
		doctor.add(doctor1);
		doctor.add(doctor2);
		doctor.add(doctor3);
		doctor.add(doctor4);
		doctor.add(doctor5);
		request.setAttribute("Doctor", doctor);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);
	}

}
