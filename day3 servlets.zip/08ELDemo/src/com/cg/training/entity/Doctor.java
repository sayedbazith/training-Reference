package com.cg.training.entity;

public class Doctor {
	private String name="rafi";
	private double consultantFee=100.00;
	private int experince=5;
	Clinic clinic=new Clinic();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getConsultantFee() {
		return consultantFee;
	}
	public void setConsultantFee(double consultantFee) {
		this.consultantFee = consultantFee;
	}
	public int getExperince() {
		return experince;
	}
	public void setExperince(int experince) {
		this.experince = experince;
	}
	public Clinic getClinic() {
		return clinic;
	}
	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}
}
