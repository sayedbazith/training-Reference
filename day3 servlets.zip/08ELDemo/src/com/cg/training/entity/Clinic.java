package com.cg.training.entity;

public class Clinic {
	private String city="chennai";
	private String location="sholinganur";
	private String pincode="533450";
	private String phoneNumber="8886385538";
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Clinic [city=" + city + ", location=" + location + ", pincode="
				+ pincode + ", phoneNumber=" + phoneNumber + "]";
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
